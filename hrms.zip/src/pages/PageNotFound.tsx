
function PageNotFound() {
  return (
    <div className='h-screen text-[30px] font-bold flex items-center justify-center'
    >PageNotFound !</div>
  )
}

export default PageNotFound