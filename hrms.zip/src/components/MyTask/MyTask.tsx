import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import React, { useContext, useEffect, useState } from "react";
import { Typography } from "@mui/material";
import { EmployeeContext } from "../../context/EmployeeContext";
import EmptyMyTask from "./EmptyMyTask";
import { TaskListResponse, Timesheet, projectInterface } from "../../types/ApiSchema";
import { Todo, Task } from "../../types/ApiSchema";
import { GlobalContext } from "../../context/GlobalContext";
import MarkCompletePopup from "../molecules/MarkCompletePopup";
import {
  DeleteCardContent,
  MarkCompleteCardContent,
  todoStatusTabs,
} from "../../constants/Constants";
import moment from "moment";
import Spinner from "react-spinner";
import { Utils } from "../../services/Utils";
import ApiServices from "../../services/APIServices";
import { toast } from "react-toastify";
interface propsInterface {
  tab: string;
}

const MyTask: React.FC<propsInterface> = ({ tab }) => {
  const {setToDoList}=useContext(EmployeeContext)
  const calculateTotalTime = (timesheets: Timesheet[]) => {
    let totalTime = 0;
   

    timesheets?.forEach((timesheet: Timesheet) => {
      const startTime = moment(timesheet?.start_time);
      const endTime = moment(timesheet?.end_time);
      const duration = moment.duration(endTime.diff(startTime));

      totalTime += duration.asMinutes(); // or asSeconds(), asHours(), etc. based on your needs
    });
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const totalHours = Math.floor(totalTime / 60);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const remainingMinutes = totalTime % 60;
    return `${totalHours}hr  ${remainingMinutes}min`;
  };
  const {  setSelectedTodo, todoFetching, TodoList } =
    useContext(EmployeeContext);
  const { setTimeSheetDrawer, setDrawer } = useContext(GlobalContext);
  const activeTab = (todoStatusTabs[parseInt(tab)] as "Completed") || "Overdue" || "Inprogress";



  const handleTimeSheetOption = (todo: Task) => {
    setSelectedTodo(todo);
    setTimeSheetDrawer(true);
    setDrawer(true);
  };


// useEffect(()=>{
//   console.log('re')
//   ApiServices.getNewTodoList(1, (response: TaskListResponse) => {
//     if (response.statusCode === 200) {
//       setToDoList(response?.data);
//     } else {
//       toast.error(response.message);
//     }
//   })
// },[])

  const [activeIndex, setActiveIndex] = useState<number | null>(null);
   
  return (
    <div className="  flex-1 flex-col     ">
      {todoFetching ? (
        <div className=" flex-1 flex flex-col justify-center items-center ">
          <Spinner
            style={{
              width: "40px", 
              height: "40px", 
              border: "2px solid #f3f3f3",
              borderTop: "2px solid #3498db",
              borderRadius: "50%",
              animation: "spin 1s linear infinite",
            }}
          /> 
        </div>
      ) : 
      TodoList?.[activeTab] && TodoList?.[activeTab].length>0 ? (
        <>
          <div className="shadow-sm rounded-xl      ">
            {TodoList?.[activeTab]?.map((todo, index) => {
              return (
                <>
                  <div
                    className={`w-full  py-2 px-4  flex justify-center items-center font-montserrat hover:bg-[#F6F6F6] group/item ${
                      activeIndex === index ? "bg-[#F6F6F6]" : ""
                    }`}
                    key={index}
                    onClick={() => {
                      setActiveIndex(index);
                    }}
                  >
                    <div className="flex justify-center items-start px-2 ">
                      <div>
                        <div
                          className={`w-[10px] mb-5  h-[10px] rounded-full  ${
                            todo?.Task_Status === "1"
                              ? "bg-[#9a98f9]"
                              : todo?.Task_Status === "2"
                              ? "bg-[#00BE35]"
                              : "bg-red-400"
                          }`}
                        ></div>
                      </div>
                    </div>
                    <div className="ml-4 flex-grow">
                      <p
                        className="text-md max-w-md text-neutral-950"
                        dangerouslySetInnerHTML={{ __html: todo?.Task }}
                      >
                        {/* {todo.Task.charAt(0).toUpperCase() +
                                            todo.Task.slice(1)} */}
                      </p>
                      <span className="text-[12px] text-neutral-600 max-w-sm capitalize">
                        {todo.project_id?.project_name} |{" "}
                        {todo && todo?.timesheets?.length > 0
                          ? calculateTotalTime(todo?.timesheets)
                          : "0 hr"}
                        {/* | {"  "} */}
                      </span>
                    </div>
                    {/* {[1, 3].includes(parseInt(todo?.Task_Status, 10)) && ( */}
                    <div className="group/edit invisible group-hover/item:visible text-black">
                      <div className="mr-4 opacity-70	md:flex flex justify-center items-center gap-6">
                        <button
                          className="flex justify-center items-center"
                          onClick={() => handleTimeSheetOption(todo)}
                          // disabled={isTaskStatus2}
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="14"
                            height="14"
                            viewBox="0 0 14 14"
                            fill="none"
                          >
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M13.1668 7.00041C13.1668 10.4064 10.4062 13.1671 7.00016 13.1671C3.59416 13.1671 0.833496 10.4064 0.833496 7.00041C0.833496 3.59441 3.59416 0.83374 7.00016 0.83374C10.4062 0.83374 13.1668 3.59441 13.1668 7.00041Z"
                              stroke="#7A797C"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                            <path
                              d="M9.28775 8.96187L6.77441 7.46253V4.2312"
                              stroke="#7A797C"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>
                          <p className="font-montserrat text-[#7A797C] text-[13px] pl-2 pr-4  ">
                            Add timesheet
                          </p>
                        </button>
                        <div className="flex justify-center items-center">
                          <MarkCompletePopup
                            todo={todo && todo}
                            content={MarkCompleteCardContent}
                          />
                        </div>

                        <div className="flex justify-center items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="12"
                            height="12"
                            viewBox="0 0 12 12"
                            fill="#7A797C"
                            style={{ marginRight: 2 }}
                          >
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              stroke="#7A797C"
                              d="M6.14387 11.8333C5.35345 11.8333 4.58287 11.8246 3.82045 11.8088C2.84512 11.7896 2.1702 11.1573 2.05995 10.1586C1.8762 8.50192 1.56179 4.59709 1.55887 4.55801C1.53904 4.31709 1.7187 4.10592 1.95962 4.08667C2.19704 4.08026 2.4117 4.24709 2.43095 4.48742C2.43387 4.52709 2.7477 8.41851 2.9297 10.0623C2.99212 10.6299 3.29837 10.9228 3.83854 10.9338C5.29687 10.9648 6.78495 10.9665 8.38912 10.9373C8.96312 10.9263 9.27345 10.6393 9.33762 10.0583C9.51845 8.42842 9.83345 4.52709 9.83695 4.48742C9.8562 4.24709 10.0691 4.07909 10.3077 4.08667C10.5486 4.10651 10.7283 4.31709 10.709 4.55801C10.7055 4.59767 10.3894 8.51242 10.2074 10.1545C10.0942 11.1736 9.42104 11.7937 8.40487 11.8123C7.62729 11.8258 6.87712 11.8333 6.14387 11.8333Z"
                              fill="#6F6CFF"
                            />
                            <path
                              d="M6.14387 11.8333C5.35345 11.8333 4.58287 11.8246 3.82045 11.8088C2.84512 11.7896 2.1702 11.1573 2.05995 10.1586C1.8762 8.50192 1.56179 4.59709 1.55887 4.55801C1.53904 4.31709 1.7187 4.10592 1.95962 4.08667C2.19704 4.08026 2.4117 4.24709 2.43095 4.48742C2.43387 4.52709 2.7477 8.41851 2.9297 10.0623C2.99212 10.6299 3.29837 10.9228 3.83854 10.9338C5.29687 10.9648 6.78495 10.9665 8.38912 10.9373C8.96312 10.9263 9.27345 10.6393 9.33762 10.0583C9.51845 8.42842 9.83345 4.52709 9.83695 4.48742C9.8562 4.24709 10.0691 4.07909 10.3077 4.08667C10.5486 4.10651 10.7283 4.31709 10.709 4.55801C10.7055 4.59767 10.3894 8.51242 10.2074 10.1545C10.0942 11.1736 9.42104 11.7937 8.40487 11.8123C7.62729 11.8258 6.87712 11.8333 6.14387 11.8333"
                              stroke="#7A797C"
                              stroke-width="0.25"
                            />
                            <path
                              fill-rule="evenodd"
                              stroke="#7A797C"
                              clip-rule="evenodd"
                              d="M11.0797 3.0769H1.1875C0.946 3.0769 0.75 2.8809 0.75 2.6394C0.75 2.3979 0.946 2.2019 1.1875 2.2019H11.0797C11.3212 2.2019 11.5172 2.3979 11.5172 2.6394C11.5172 2.8809 11.3212 3.0769 11.0797 3.0769Z"
                              fill="#7A797C"
                            />
                            <path
                              d="M11.0797 3.0769H1.1875C0.946 3.0769 0.75 2.8809 0.75 2.6394C0.75 2.3979 0.946 2.2019 1.1875 2.2019H11.0797C11.3212 2.2019 11.5172 2.3979 11.5172 2.6394C11.5172 2.8809 11.3212 3.0769 11.0797 3.0769"
                              stroke="#7A797C"
                              stroke-width="0.25"
                            />
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              stroke="#7A797C"
                              d="M9.17359 3.077C8.50976 3.077 7.93342 2.60391 7.80276 1.95291L7.66101 1.24358C7.63126 1.13566 7.50817 1.04175 7.36817 1.04175H4.89892C4.75892 1.04175 4.63584 1.13566 4.60026 1.27041L4.46434 1.95291C4.33426 2.60391 3.75734 3.077 3.09351 3.077C2.85201 3.077 2.65601 2.881 2.65601 2.6395C2.65601 2.398 2.85201 2.202 3.09351 2.202C3.34201 2.202 3.55784 2.02466 3.60684 1.78083L3.74859 1.0715C3.89267 0.527831 4.36342 0.166748 4.89892 0.166748H7.36817C7.90367 0.166748 8.37442 0.527831 8.51267 1.04525L8.66084 1.78083C8.70926 2.02466 8.92509 2.202 9.17359 2.202C9.41509 2.202 9.61109 2.398 9.61109 2.6395C9.61109 2.881 9.41509 3.077 9.17359 3.077Z"
                              fill="#7A797C"
                            />
                            <path
                              d="M9.17359 3.077C8.50976 3.077 7.93342 2.60391 7.80276 1.95291L7.66101 1.24358C7.63126 1.13566 7.50817 1.04175 7.36817 1.04175H4.89892C4.75892 1.04175 4.63584 1.13566 4.60026 1.27041L4.46434 1.95291C4.33426 2.60391 3.75734 3.077 3.09351 3.077C2.85201 3.077 2.65601 2.881 2.65601 2.6395C2.65601 2.398 2.85201 2.202 3.09351 2.202C3.34201 2.202 3.55784 2.02466 3.60684 1.78083L3.74859 1.0715C3.89267 0.527831 4.36342 0.166748 4.89892 0.166748H7.36817C7.90367 0.166748 8.37442 0.527831 8.51267 1.04525L8.66084 1.78083C8.70926 2.02466 8.92509 2.202 9.17359 2.202C9.41509 2.202 9.61109 2.398 9.61109 2.6395C9.61109 2.881 9.41509 3.077 9.17359 3.077"
                              stroke="#7A797C"
                              stroke-width="0.10"
                            />
                          </svg>

                          <MarkCompletePopup
                            todo={todo}
                            content={DeleteCardContent}
                          />
                        </div>
                      </div>
                    </div>
                    {/* )} */}
                  </div>
                </>
              );
            })}
          </div>
        </> 
      ) : (
        <div>
          <EmptyMyTask />
        </div>
      )}
    </div>
  );
};

export default MyTask;
