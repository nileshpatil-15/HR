import Profile from "./Profile"
import RecentClockin from "../RecentClockins/RecentClockins"

function ProfileView() {
  return (
    <div>
      <Profile/>
      <RecentClockin/> 
    </div>
  )
}

export default ProfileView
