// import {  useEffect, useState } from "react";
import { Avatar } from "@mui/material";
import { deepOrange } from "@mui/material/colors";
import { Utils } from "../../services/Utils";


function Profile() {

  const user = Utils.getUserData();
  return (
    <>
      <div className="border-b">
        <div className="p-3 flex flex-col justify-center items-center">
          <div className="p-1 border rounded-full bg-gradient-to-b from-purple-600 via-indigo-600 to-blue-500">
            
              <Avatar
                // src={profileData.avatarUrl}
                // src={user?.avatarUrl || defaultAvatarUrl}
                src="https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"

                sx={{
                  bgcolor: deepOrange[500],
                  width: "100px",
                  height: "100px",
                  border: 3,
                }}
                alt=""
              ></Avatar>
          </div>
          <div className="flex flex-col justify-center items-center font-montserrat">
            <p className="text-md font-semibold text-neutral-700 capitalize">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="text-sm text-neutral-600 ">{user?.emp_position}</p>
          </div>
          
        </div>
      </div>
    </>
  );
}

export default Profile;
