import { toast } from "react-toastify";
import {
  CreateTodo,
  Employee_Login,
  GetToDoList,
  deleteToDo,
  updateTodo,
  checkClockInStatus,
  AddTimeSheet,
  MarkComplete,
  getTimeSheet,
  GetClockinList,
  GetToDoListonDate,
  DeleteTime,
  UpdateTime,
  NewGetTodoList,
  TimesheetDates,
  
} from "../constants/APIEndpoints";
import { ProjectList } from "../constants/APIEndpoints";
import { Utils } from "./Utils";
import { TimeConversion } from "../types/ApiSchema";
import { ClockIn } from "../constants/APIEndpoints";
// import { GlobalContext } from "../context/GlobalContext";
// import { useContext } from "react";
export default class ApiServices {
  public static tokenKey = "token";

  static login = async (
    email: string,
    password: string,
    rememberMe: boolean,
    // eslint-disable-next-line @typescript-eslint/ban-types
    next: Function
  ) => {
    const myHeader = new Headers();
    myHeader.append("Content-Type", "application/json");

    try {
      const response = await fetch(Employee_Login, {
        method: "POST",
        headers: myHeader,
        body: JSON.stringify({
          officialEmail: email,
          password: password,
        }),
      });

      const result = await response.json();
      if (result.statusCode === 201) {
        
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      toast.error("Something went wrong");
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types
  static getProjectList = async (next: Function) => {
    const myHeader = new Headers();
    myHeader.append("Content-Type", "application/json");

    try {
      let token;
      if (localStorage.getItem(this.tokenKey) !== null) {
        token = localStorage.getItem(this.tokenKey);
      } else {
        token = sessionStorage.getItem(this.tokenKey);
      }
      const response = await fetch(ProjectList, {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        toast(errorData.message);
      }
      const result = await response.json();

      if (result.statusCode === 200) {
        next(result);
      } else {
        toast(result.message);
      }
      // next(result);
    } catch (err) {
      next(err);
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types
  static clockIn = async (next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }
    try {
      const response = await fetch(ClockIn, {
        method: "POST",
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Entry_Type: "Office",
        }),
      });
      

      const result = await response.json();

      if (result.statusCode === 201) {
        next(result);
      } else {
       next(result)
      }
    } catch (err) {
     
      toast.error("Something went wrong");
    }
  };
  // eslint-disable-next-line @typescript-eslint/ban-types
  static createToDo = async (task: string, project: string, next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }

    try {
      const response = await fetch(CreateTodo, {
        method: "POST",
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Task: task,
          project_id: project,
        }),
      });
      const result = await response.json();
        if (result.statusCode === 201) {
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      toast.error('Something went wrong !')
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types
  static getToDoList = async (next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }
    try {
      const response = await fetch(GetToDoList, {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });
      const result = await response.json();
      if (result.statusCode === 200) {
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      next(err);
    }
  };
  // eslint-disable-next-line @typescript-eslint/ban-types
  static deleteTodo = async (todoId: string, next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }

    try {
      const response = await fetch(deleteToDo + todoId, {
        method: "PATCH",
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });
      const result = await response.json();
      if (!response.ok) {
        
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      next(err);
    }
  };
  static updateTodo = async (
    todo: string,
    TodoId: string,
    project_id: string | undefined,
    // eslint-disable-next-line @typescript-eslint/ban-types
    next: Function
  ) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }

    try {
      const response = await fetch(updateTodo + TodoId, {
        method: "PUT",
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Task: todo,
          project_id,
        }),
      });

      const result = await response.json();
      if (!response.ok) {
        next(result);
      } else if (result.statusCode === 200) {
        next(result);
      } else next(result);
    } catch (err) {
      next(err);
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types
  static checkClockInStatus = async (next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }

    try {
      const response = await fetch(checkClockInStatus, {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });
      const result = await response.json();

      if (!response.ok) {
        next(result);
      } else if (result.statusCode === 200) {
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      next(err);
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types, @typescript-eslint/no-unused-vars
  static addTimesheet = async (
    toDoId: string,
    time: TimeConversion,
    // eslint-disable-next-line @typescript-eslint/ban-types
    next: Function 
  ) => {
    // console.log(time.end_time,'add')
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }

    try {
      const response = await fetch(AddTimeSheet + toDoId, {
        method: "POST",
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          start_time: time.start_time,
          end_time: time.end_time,
        }),
      });
      const result = await response.json();
      if (result.statusCode === 201) {
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      next(err);
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types

  // eslint-disable-next-line @typescript-eslint/ban-types
  static MarkTodoComplete = async (todoId: string, next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }
    try {
      const response = await fetch(MarkComplete + todoId, {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });

      const result = await response.json();
      if (result.statusCode === 200) {
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      next(err);
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types
  static getTimeSheet = async (todoId: string, next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }
    try {
      const response = await fetch(getTimeSheet + todoId, {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });

      const result = await response.json();
      if (result.statusCode === 200) {
        next(result);
      } else {
        next(result);
      }
    } catch (err) {
      next(err);
    }
  };
  //Recent clockIn List
  // eslint-disable-next-line @typescript-eslint/ban-types
  static getTimesheetDates = async (next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }
    try {
      const response = await fetch(TimesheetDates, {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });
      const result = await response.json();
      if (result.statusCode === 200) {
        next(result) 
      } else {
        toast(result);
      }
    } catch (err) {
      next(err);
    }
  };

  // eslint-disable-next-line @typescript-eslint/ban-types
  static getTimeSheetDetails = async (date: string, next: Function) => {
    let token;
    if (localStorage.getItem(this.tokenKey) !== null) {
      token = localStorage.getItem(this.tokenKey);
    } else {
      token = sessionStorage.getItem(this.tokenKey);
    }
    try {
      const response = await fetch(GetToDoListonDate +`${date}&page=1&recordsPerPage=5&showAll=false`, {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      });
      const result = await response.json();
      if (result.statusCode === 200) {

        next(result);
      } else {
        toast.error(result.message);
      }
    } catch (err) {
      next(err);
    }
  };
  
  
  // eslint-disable-next-line @typescript-eslint/ban-types
static DeleteTime = async (timesheet_Id: string, timeIndex: number, next: Function) => {
  let token;
  if (localStorage.getItem(this.tokenKey) !== null) {
    token = localStorage.getItem(this.tokenKey);
  } else {
    token = sessionStorage.getItem(this.tokenKey);
  }
  try {
    const response = await fetch(DeleteTime +timesheet_Id, {
      method: 'PATCH',
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ timesheet_Id, timeIndex }),
    });

    const result = await response.json();
    if (result.statusCode === 200) {
      next(result);
    } else {
      toast.error(result.message);
    }
  } catch (err) {
    next(err);
  }
};
static updateTime = async (
  todo: string,
  timesheet_Id: string,
  project_id: string | undefined,
  // eslint-disable-next-line @typescript-eslint/ban-types
  next: Function
) => {
  let token;
  if (localStorage.getItem(this.tokenKey) !== null) {
    token = localStorage.getItem(this.tokenKey);
  } else {
    token = sessionStorage.getItem(this.tokenKey);
  }

  try {
    const response = await fetch(UpdateTime + timesheet_Id, {
      method: "PUT",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        Task: todo,
        project_id,
        timesheet_Id
      }),
    });

    const result = await response.json();
    if (!response.ok) {
      next(result);
    } else if (result.statusCode === 200) {
      next(result);
    } else next(result);
  } catch (err) {
    next(err);
  }
};


   static getNewTodoList=async (tab: number| undefined,next:Function)=>{

    try{
      let token;
      if (localStorage.getItem(this.tokenKey) !== null) {
        token = localStorage.getItem(this.tokenKey);
      } else {
        token = sessionStorage.getItem(this.tokenKey);
      }

      const response=await fetch(NewGetTodoList+tab,{
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      }) 
      

      
      const result=await response.json()
if(result.statusCode===200){
  next(result)
}
else{
  next(result)
}
    }
    catch(err){
     toast.error('something went wrong');
      
    }
   }
}
